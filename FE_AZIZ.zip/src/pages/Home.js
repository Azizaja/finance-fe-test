import React from 'react';

const Home = () => {
  return (
    <div>
      <h2>Selamat datang di Halaman Home!</h2>
      {/* Tambahkan konten halaman utama di sini */}
    </div>
  );
};

export default Home;
